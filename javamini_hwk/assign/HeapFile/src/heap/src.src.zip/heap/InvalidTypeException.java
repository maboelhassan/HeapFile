/*    */ package heap;
/*    */ 
/*    */ import chainexception.ChainException;
/*    */ 
/*    */ public class InvalidTypeException extends ChainException
/*    */ {
/*    */   public InvalidTypeException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public InvalidTypeException(Exception paramException, String paramString)
/*    */   {
/* 15 */     super(paramException, paramString);
/*    */   }
/*    */ }

/* Location:           C:\Users\Ahmed\Documents\GitHub\HeapFile\javamini_hwk\assign\HeapFile\src\
 * Qualified Name:     heap.InvalidTypeException
 * JD-Core Version:    0.6.2
 */