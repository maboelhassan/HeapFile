/*     */ package heap;
/*     */ 
/*     */ import diskmgr.Page;
/*     */ import global.Convert;
/*     */ import global.GlobalConst;
/*     */ import global.PageId;
/*     */ import global.RID;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class HFPage extends Page
/*     */   implements ConstSlot, GlobalConst
/*     */ {
/*     */   public static final int SIZE_OF_SLOT = 4;
/*     */   public static final int DPFIXED = 20;
/*     */   public static final int SLOT_CNT = 0;
/*     */   public static final int USED_PTR = 2;
/*     */   public static final int FREE_SPACE = 4;
/*     */   public static final int TYPE = 6;
/*     */   public static final int PREV_PAGE = 8;
/*     */   public static final int NEXT_PAGE = 12;
/*     */   public static final int CUR_PAGE = 16;
/*     */   private short slotCnt;
/*     */   private short usedPtr;
/*     */   private short freeSpace;
/*     */   private short type;
/*  71 */   private PageId prevPage = new PageId();
/*     */ 
/*  76 */   private PageId nextPage = new PageId();
/*     */ 
/*  81 */   protected PageId curPage = new PageId();
/*     */ 
/*     */   public HFPage()
/*     */   {
/*     */   }
/*     */ 
/*     */   public HFPage(Page paramPage)
/*     */   {
/*  97 */     this.data = paramPage.getpage();
/*     */   }
/*     */ 
/*     */   public void openHFpage(Page paramPage)
/*     */   {
/* 108 */     this.data = paramPage.getpage();
/*     */   }
/*     */ 
/*     */   public void init(PageId paramPageId, Page paramPage)
/*     */     throws IOException
/*     */   {
/* 124 */     this.data = paramPage.getpage();
/*     */ 
/* 126 */     this.slotCnt = 0;
/* 127 */     Convert.setShortValue(this.slotCnt, 0, this.data);
/*     */ 
/* 129 */     this.curPage.pid = paramPageId.pid;
/* 130 */     Convert.setIntValue(this.curPage.pid, 16, this.data);
/*     */ 
/* 132 */     this.nextPage.pid = (this.prevPage.pid = -1);
/* 133 */     Convert.setIntValue(this.prevPage.pid, 8, this.data);
/* 134 */     Convert.setIntValue(this.nextPage.pid, 12, this.data);
/*     */ 
/* 136 */     this.usedPtr = 1024;
/* 137 */     Convert.setShortValue(this.usedPtr, 2, this.data);
/*     */ 
/* 139 */     this.freeSpace = 1004;
/* 140 */     Convert.setShortValue(this.freeSpace, 4, this.data);
/*     */   }
/*     */ 
/*     */   public byte[] getHFpageArray()
/*     */   {
/* 150 */     return this.data;
/*     */   }
/*     */ 
/*     */   public void dumpPage()
/*     */     throws IOException
/*     */   {
/* 163 */     this.curPage.pid = Convert.getIntValue(16, this.data);
/* 164 */     this.nextPage.pid = Convert.getIntValue(12, this.data);
/* 165 */     this.usedPtr = Convert.getShortValue(2, this.data);
/* 166 */     this.freeSpace = Convert.getShortValue(4, this.data);
/* 167 */     this.slotCnt = Convert.getShortValue(0, this.data);
/*     */ 
/* 169 */     System.out.println("dumpPage");
/* 170 */     System.out.println("curPage= " + this.curPage.pid);
/* 171 */     System.out.println("nextPage= " + this.nextPage.pid);
/* 172 */     System.out.println("usedPtr= " + this.usedPtr);
/* 173 */     System.out.println("freeSpace= " + this.freeSpace);
/* 174 */     System.out.println("slotCnt= " + this.slotCnt);
/*     */ 
/* 176 */     int i = 0; for (int j = 20; i < this.slotCnt; i++) {
/* 177 */       int k = Convert.getShortValue(j, this.data);
/* 178 */       int m = Convert.getShortValue(j + 2, this.data);
/* 179 */       System.out.println("slotNo " + i + " offset= " + m);
/* 180 */       System.out.println("slotNo " + i + " length= " + k);
/*     */ 
/* 176 */       j += 4;
/*     */     }
/*     */   }
/*     */ 
/*     */   public PageId getPrevPage()
/*     */     throws IOException
/*     */   {
/* 192 */     this.prevPage.pid = Convert.getIntValue(8, this.data);
/* 193 */     return this.prevPage;
/*     */   }
/*     */ 
/*     */   public void setPrevPage(PageId paramPageId)
/*     */     throws IOException
/*     */   {
/* 204 */     this.prevPage.pid = paramPageId.pid;
/* 205 */     Convert.setIntValue(this.prevPage.pid, 8, this.data);
/*     */   }
/*     */ 
/*     */   public PageId getNextPage()
/*     */     throws IOException
/*     */   {
/* 215 */     this.nextPage.pid = Convert.getIntValue(12, this.data);
/* 216 */     return this.nextPage;
/*     */   }
/*     */ 
/*     */   public void setNextPage(PageId paramPageId)
/*     */     throws IOException
/*     */   {
/* 227 */     this.nextPage.pid = paramPageId.pid;
/* 228 */     Convert.setIntValue(this.nextPage.pid, 12, this.data);
/*     */   }
/*     */ 
/*     */   public PageId getCurPage()
/*     */     throws IOException
/*     */   {
/* 238 */     this.curPage.pid = Convert.getIntValue(16, this.data);
/* 239 */     return this.curPage;
/*     */   }
/*     */ 
/*     */   public void setCurPage(PageId paramPageId)
/*     */     throws IOException
/*     */   {
/* 250 */     this.curPage.pid = paramPageId.pid;
/* 251 */     Convert.setIntValue(this.curPage.pid, 16, this.data);
/*     */   }
/*     */ 
/*     */   public short getType()
/*     */     throws IOException
/*     */   {
/* 261 */     this.type = Convert.getShortValue(6, this.data);
/* 262 */     return this.type;
/*     */   }
/*     */ 
/*     */   public void setType(short paramShort)
/*     */     throws IOException
/*     */   {
/* 273 */     this.type = paramShort;
/* 274 */     Convert.setShortValue(this.type, 6, this.data);
/*     */   }
/*     */ 
/*     */   public short getSlotCnt()
/*     */     throws IOException
/*     */   {
/* 284 */     this.slotCnt = Convert.getShortValue(0, this.data);
/* 285 */     return this.slotCnt;
/*     */   }
/*     */ 
/*     */   public void setSlot(int paramInt1, int paramInt2, int paramInt3)
/*     */     throws IOException
/*     */   {
/* 298 */     int i = 20 + paramInt1 * 4;
/* 299 */     Convert.setShortValue((short)paramInt2, i, this.data);
/* 300 */     Convert.setShortValue((short)paramInt3, i + 2, this.data);
/*     */   }
/*     */ 
/*     */   public short getSlotLength(int paramInt)
/*     */     throws IOException
/*     */   {
/* 311 */     int i = 20 + paramInt * 4;
/* 312 */     short s = Convert.getShortValue(i, this.data);
/* 313 */     return s;
/*     */   }
/*     */ 
/*     */   public short getSlotOffset(int paramInt)
/*     */     throws IOException
/*     */   {
/* 324 */     int i = 20 + paramInt * 4;
/* 325 */     short s = Convert.getShortValue(i + 2, this.data);
/* 326 */     return s;
/*     */   }
/*     */ 
/*     */   public RID insertRecord(byte[] paramArrayOfByte)
/*     */     throws IOException
/*     */   {
/* 340 */     RID localRID = new RID();
/*     */ 
/* 342 */     int i = paramArrayOfByte.length;
/* 343 */     int j = i + 4;
/*     */ 
/* 349 */     this.freeSpace = Convert.getShortValue(4, this.data);
/* 350 */     if (j > this.freeSpace) {
/* 351 */       return null;
/*     */     }
/*     */ 
/* 356 */     this.slotCnt = Convert.getShortValue(0, this.data);
/*     */ 
/* 359 */     for (int k = 0; k < this.slotCnt; k++)
/*     */     {
/* 361 */       int m = getSlotLength(k);
/* 362 */       if (m == -1) {
/*     */         break;
/*     */       }
/*     */     }
/* 366 */     if (k == this.slotCnt)
/*     */     {
/* 369 */       this.freeSpace = ((short)(this.freeSpace - j));
/* 370 */       Convert.setShortValue(this.freeSpace, 4, this.data);
/*     */ 
/* 372 */       this.slotCnt = ((short)(this.slotCnt + 1));
/* 373 */       Convert.setShortValue(this.slotCnt, 0, this.data);
/*     */     }
/*     */     else
/*     */     {
/* 378 */       this.freeSpace = ((short)(this.freeSpace - i));
/* 379 */       Convert.setShortValue(this.freeSpace, 4, this.data);
/*     */     }
/*     */ 
/* 382 */     this.usedPtr = Convert.getShortValue(2, this.data);
/* 383 */     this.usedPtr = ((short)(this.usedPtr - i));
/* 384 */     Convert.setShortValue(this.usedPtr, 2, this.data);
/*     */ 
/* 387 */     setSlot(k, i, this.usedPtr);
/*     */ 
/* 390 */     System.arraycopy(paramArrayOfByte, 0, this.data, this.usedPtr, i);
/* 391 */     this.curPage.pid = Convert.getIntValue(16, this.data);
/* 392 */     localRID.pageNo.pid = this.curPage.pid;
/* 393 */     localRID.slotNo = k;
/* 394 */     return localRID;
/*     */   }
/*     */ 
/*     */   public void deleteRecord(RID paramRID)
/*     */     throws IOException, InvalidSlotNumberException
/*     */   {
/* 409 */     int i = paramRID.slotNo;
/* 410 */     int j = getSlotLength(i);
/* 411 */     this.slotCnt = Convert.getShortValue(0, this.data);
/*     */ 
/* 414 */     if ((i >= 0) && (i < this.slotCnt) && (j > 0))
/*     */     {
/* 421 */       int k = getSlotOffset(i);
/* 422 */       this.usedPtr = Convert.getShortValue(2, this.data);
/* 423 */       int m = this.usedPtr + j;
/* 424 */       int n = k - this.usedPtr;
/*     */ 
/* 427 */       System.arraycopy(this.data, this.usedPtr, this.data, m, n);
/*     */ 
/* 433 */       int i1 = 0; for (int i2 = 20; i1 < this.slotCnt; i1++) {
/* 434 */         if (getSlotLength(i1) >= 0)
/*     */         {
/* 436 */           int i3 = getSlotOffset(i1);
/* 437 */           if (i3 < k)
/*     */           {
/* 439 */             i3 += j;
/* 440 */             Convert.setShortValue((short)i3, i2 + 2, this.data);
/*     */           }
/*     */         }
/* 433 */         i2 += 4;
/*     */       }
/*     */ 
/* 446 */       this.usedPtr = ((short)(this.usedPtr + j));
/* 447 */       Convert.setShortValue(this.usedPtr, 2, this.data);
/*     */ 
/* 450 */       this.freeSpace = Convert.getShortValue(4, this.data);
/* 451 */       this.freeSpace = ((short)(this.freeSpace + j));
/* 452 */       Convert.setShortValue(this.freeSpace, 4, this.data);
/*     */ 
/* 454 */       setSlot(i, -1, 0);
/*     */     }
/*     */     else {
/* 457 */       throw new InvalidSlotNumberException(null, "HEAPFILE: INVALID_SLOTNO");
/*     */     }
/*     */   }
/*     */ 
/*     */   public RID firstRecord()
/*     */     throws IOException
/*     */   {
/* 470 */     RID localRID = new RID();
/*     */ 
/* 474 */     this.slotCnt = Convert.getShortValue(0, this.data);
/*     */ 
/* 478 */     for (int i = 0; i < this.slotCnt; i++)
/*     */     {
/* 480 */       int j = getSlotLength(i);
/* 481 */       if (j != -1) {
/*     */         break;
/*     */       }
/*     */     }
/* 485 */     if (i == this.slotCnt) {
/* 486 */       return null;
/*     */     }
/*     */ 
/* 490 */     localRID.slotNo = i;
/* 491 */     this.curPage.pid = Convert.getIntValue(16, this.data);
/* 492 */     localRID.pageNo.pid = this.curPage.pid;
/*     */ 
/* 494 */     return localRID;
/*     */   }
/*     */ 
/*     */   public RID nextRecord(RID paramRID)
/*     */     throws IOException
/*     */   {
/* 507 */     RID localRID = new RID();
/* 508 */     this.slotCnt = Convert.getShortValue(0, this.data);
/*     */ 
/* 510 */     int i = paramRID.slotNo;
/*     */ 
/* 514 */     for (i++; i < this.slotCnt; i++)
/*     */     {
/* 516 */       int j = getSlotLength(i);
/* 517 */       if (j != -1) {
/*     */         break;
/*     */       }
/*     */     }
/* 521 */     if (i >= this.slotCnt) {
/* 522 */       return null;
/*     */     }
/*     */ 
/* 526 */     localRID.slotNo = i;
/* 527 */     this.curPage.pid = Convert.getIntValue(16, this.data);
/* 528 */     localRID.pageNo.pid = this.curPage.pid;
/*     */ 
/* 530 */     return localRID;
/*     */   }
/*     */ 
/*     */   public Tuple getRecord(RID paramRID)
/*     */     throws IOException, InvalidSlotNumberException
/*     */   {
/* 550 */     PageId localPageId = new PageId();
/* 551 */     localPageId.pid = paramRID.pageNo.pid;
/* 552 */     this.curPage.pid = Convert.getIntValue(16, this.data);
/* 553 */     int k = paramRID.slotNo;
/*     */ 
/* 556 */     int i = getSlotLength(k);
/* 557 */     this.slotCnt = Convert.getShortValue(0, this.data);
/* 558 */     if ((k >= 0) && (k < this.slotCnt) && (i > 0) && 
/* 559 */       (localPageId.pid == this.curPage.pid))
/*     */     {
/* 561 */       int j = getSlotOffset(k);
/* 562 */       byte[] arrayOfByte = new byte[i];
/* 563 */       System.arraycopy(this.data, j, arrayOfByte, 0, i);
/* 564 */       Tuple localTuple = new Tuple(arrayOfByte, 0, i);
/* 565 */       return localTuple;
/*     */     }
/*     */ 
/* 569 */     throw new InvalidSlotNumberException(null, "HEAPFILE: INVALID_SLOTNO");
/*     */   }
/*     */ 
/*     */   public Tuple returnRecord(RID paramRID)
/*     */     throws IOException, InvalidSlotNumberException
/*     */   {
/* 591 */     PageId localPageId = new PageId();
/* 592 */     localPageId.pid = paramRID.pageNo.pid;
/*     */ 
/* 594 */     this.curPage.pid = Convert.getIntValue(16, this.data);
/* 595 */     int k = paramRID.slotNo;
/*     */ 
/* 598 */     int i = getSlotLength(k);
/* 599 */     this.slotCnt = Convert.getShortValue(0, this.data);
/*     */ 
/* 601 */     if ((k >= 0) && (k < this.slotCnt) && (i > 0) && 
/* 602 */       (localPageId.pid == this.curPage.pid))
/*     */     {
/* 605 */       int j = getSlotOffset(k);
/* 606 */       Tuple localTuple = new Tuple(this.data, j, i);
/* 607 */       return localTuple;
/*     */     }
/*     */ 
/* 611 */     throw new InvalidSlotNumberException(null, "HEAPFILE: INVALID_SLOTNO");
/*     */   }
/*     */ 
/*     */   public int available_space()
/*     */     throws IOException
/*     */   {
/* 624 */     this.freeSpace = Convert.getShortValue(4, this.data);
/* 625 */     return this.freeSpace - 4;
/*     */   }
/*     */ 
/*     */   public boolean empty()
/*     */     throws IOException
/*     */   {
/* 639 */     this.slotCnt = Convert.getShortValue(0, this.data);
/*     */ 
/* 641 */     for (int i = 0; i < this.slotCnt; i++)
/*     */     {
/* 643 */       int j = getSlotLength(i);
/* 644 */       if (j != -1) {
/* 645 */         return false;
/*     */       }
/*     */     }
/* 648 */     return true;
/*     */   }
/*     */ 
/*     */   protected void compact_slot_dir()
/*     */     throws IOException
/*     */   {
/* 660 */     int i = 0;
/* 661 */     int j = -1;
/* 662 */     int k = 0;
/*     */ 
/* 666 */     this.slotCnt = Convert.getShortValue(0, this.data);
/* 667 */     this.freeSpace = Convert.getShortValue(4, this.data);
/*     */ 
/* 669 */     while (i < this.slotCnt)
/*     */     {
/* 671 */       int m = getSlotLength(i);
/*     */ 
/* 673 */       if ((m == -1) && (k == 0))
/*     */       {
/* 675 */         k = 1;
/* 676 */         j = i;
/*     */       }
/* 678 */       else if ((m != -1) && (k == 1))
/*     */       {
/* 680 */         int n = getSlotOffset(i);
/*     */ 
/* 684 */         setSlot(j, m, n);
/*     */ 
/* 688 */         setSlot(i, -1, 0);
/*     */ 
/* 691 */         j++;
/*     */ 
/* 694 */         while (getSlotLength(j) != -1)
/*     */         {
/* 696 */           j++;
/*     */         }
/*     */       }
/*     */ 
/* 700 */       i++;
/*     */     }
/*     */ 
/* 703 */     if (k == 1)
/*     */     {
/* 706 */       this.freeSpace = ((short)(this.freeSpace + 4 * (this.slotCnt - j)));
/* 707 */       this.slotCnt = ((short)j);
/* 708 */       Convert.setShortValue(this.freeSpace, 4, this.data);
/* 709 */       Convert.setShortValue(this.slotCnt, 0, this.data);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Ahmed\Documents\GitHub\HeapFile\javamini_hwk\assign\HeapFile\src\
 * Qualified Name:     heap.HFPage
 * JD-Core Version:    0.6.2
 */