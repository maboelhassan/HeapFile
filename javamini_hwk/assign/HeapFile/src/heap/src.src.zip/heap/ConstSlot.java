package heap;

interface ConstSlot
{
  public static final int INVALID_SLOT = -1;
  public static final int EMPTY_SLOT = -1;
}

/* Location:           C:\Users\Ahmed\Documents\GitHub\HeapFile\javamini_hwk\assign\HeapFile\src\
 * Qualified Name:     heap.ConstSlot
 * JD-Core Version:    0.6.2
 */