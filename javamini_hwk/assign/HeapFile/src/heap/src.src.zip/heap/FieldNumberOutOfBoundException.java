/*    */ package heap;
/*    */ 
/*    */ import chainexception.ChainException;
/*    */ 
/*    */ public class FieldNumberOutOfBoundException extends ChainException
/*    */ {
/*    */   public FieldNumberOutOfBoundException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FieldNumberOutOfBoundException(Exception paramException, String paramString)
/*    */   {
/* 13 */     super(paramException, paramString);
/*    */   }
/*    */ }

/* Location:           C:\Users\Ahmed\Documents\GitHub\HeapFile\javamini_hwk\assign\HeapFile\src\
 * Qualified Name:     heap.FieldNumberOutOfBoundException
 * JD-Core Version:    0.6.2
 */