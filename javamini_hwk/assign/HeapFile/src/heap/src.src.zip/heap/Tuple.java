/*     */ package heap;
/*     */ 
/*     */ import global.AttrType;
/*     */ import global.Convert;
/*     */ import global.GlobalConst;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class Tuple
/*     */   implements GlobalConst
/*     */ {
/*     */   public static final int max_size = 1024;
/*     */   private byte[] data;
/*     */   private int tuple_offset;
/*     */   private int tuple_length;
/*     */   private short fldCnt;
/*     */   private short[] fldOffset;
/*     */ 
/*     */   public Tuple()
/*     */   {
/*  54 */     this.data = new byte[1024];
/*  55 */     this.tuple_offset = 0;
/*  56 */     this.tuple_length = 1024;
/*     */   }
/*     */ 
/*     */   public Tuple(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */   {
/*  67 */     this.data = paramArrayOfByte;
/*  68 */     this.tuple_offset = paramInt1;
/*  69 */     this.tuple_length = paramInt2;
/*     */   }
/*     */ 
/*     */   public Tuple(Tuple paramTuple)
/*     */   {
/*  79 */     this.data = paramTuple.getTupleByteArray();
/*  80 */     this.tuple_length = paramTuple.getLength();
/*  81 */     this.tuple_offset = 0;
/*  82 */     this.fldCnt = paramTuple.noOfFlds();
/*  83 */     this.fldOffset = paramTuple.copyFldOffset();
/*     */   }
/*     */ 
/*     */   public Tuple(int paramInt)
/*     */   {
/*  94 */     this.data = new byte[paramInt];
/*  95 */     this.tuple_offset = 0;
/*  96 */     this.tuple_length = paramInt;
/*     */   }
/*     */ 
/*     */   public void tupleCopy(Tuple paramTuple)
/*     */   {
/* 105 */     byte[] arrayOfByte = paramTuple.getTupleByteArray();
/* 106 */     System.arraycopy(arrayOfByte, 0, this.data, this.tuple_offset, this.tuple_length);
/*     */   }
/*     */ 
/*     */   public void tupleInit(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */   {
/* 119 */     this.data = paramArrayOfByte;
/* 120 */     this.tuple_offset = paramInt1;
/* 121 */     this.tuple_length = paramInt2;
/*     */   }
/*     */ 
/*     */   public void tupleSet(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */   {
/* 132 */     System.arraycopy(paramArrayOfByte, paramInt1, this.data, 0, paramInt2);
/* 133 */     this.tuple_offset = 0;
/* 134 */     this.tuple_length = paramInt2;
/*     */   }
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 143 */     return this.tuple_length;
/*     */   }
/*     */ 
/*     */   public short size()
/*     */   {
/* 152 */     return (short)(this.fldOffset[this.fldCnt] - this.tuple_offset);
/*     */   }
/*     */ 
/*     */   public int getOffset()
/*     */   {
/* 160 */     return this.tuple_offset;
/*     */   }
/*     */ 
/*     */   public byte[] getTupleByteArray()
/*     */   {
/* 170 */     byte[] arrayOfByte = new byte[this.tuple_length];
/* 171 */     System.arraycopy(this.data, this.tuple_offset, arrayOfByte, 0, this.tuple_length);
/* 172 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   public byte[] returnTupleByteArray()
/*     */   {
/* 181 */     return this.data;
/*     */   }
/*     */ 
/*     */   public int getIntFld(int paramInt)
/*     */     throws IOException, FieldNumberOutOfBoundException
/*     */   {
/* 198 */     if ((paramInt > 0) && (paramInt <= this.fldCnt))
/*     */     {
/* 200 */       int i = Convert.getIntValue(this.fldOffset[(paramInt - 1)], this.data);
/* 201 */       return i;
/*     */     }
/*     */ 
/* 204 */     throw new FieldNumberOutOfBoundException(null, "TUPLE:TUPLE_FLDNO_OUT_OF_BOUND");
/*     */   }
/*     */ 
/*     */   public float getFloFld(int paramInt)
/*     */     throws IOException, FieldNumberOutOfBoundException
/*     */   {
/* 221 */     if ((paramInt > 0) && (paramInt <= this.fldCnt))
/*     */     {
/* 223 */       float f = Convert.getFloValue(this.fldOffset[(paramInt - 1)], this.data);
/* 224 */       return f;
/*     */     }
/*     */ 
/* 227 */     throw new FieldNumberOutOfBoundException(null, "TUPLE:TUPLE_FLDNO_OUT_OF_BOUND");
/*     */   }
/*     */ 
/*     */   public String getStrFld(int paramInt)
/*     */     throws IOException, FieldNumberOutOfBoundException
/*     */   {
/* 245 */     if ((paramInt > 0) && (paramInt <= this.fldCnt))
/*     */     {
/* 247 */       String str = Convert.getStrValue(this.fldOffset[(paramInt - 1)], this.data, 
/* 248 */         this.fldOffset[paramInt] - this.fldOffset[(paramInt - 1)]);
/* 249 */       return str;
/*     */     }
/*     */ 
/* 252 */     throw new FieldNumberOutOfBoundException(null, "TUPLE:TUPLE_FLDNO_OUT_OF_BOUND");
/*     */   }
/*     */ 
/*     */   public char getCharFld(int paramInt)
/*     */     throws IOException, FieldNumberOutOfBoundException
/*     */   {
/* 269 */     if ((paramInt > 0) && (paramInt <= this.fldCnt))
/*     */     {
/* 271 */       char c = Convert.getCharValue(this.fldOffset[(paramInt - 1)], this.data);
/* 272 */       return c;
/*     */     }
/*     */ 
/* 275 */     throw new FieldNumberOutOfBoundException(null, "TUPLE:TUPLE_FLDNO_OUT_OF_BOUND");
/*     */   }
/*     */ 
/*     */   public Tuple setIntFld(int paramInt1, int paramInt2)
/*     */     throws IOException, FieldNumberOutOfBoundException
/*     */   {
/* 291 */     if ((paramInt1 > 0) && (paramInt1 <= this.fldCnt))
/*     */     {
/* 293 */       Convert.setIntValue(paramInt2, this.fldOffset[(paramInt1 - 1)], this.data);
/* 294 */       return this;
/*     */     }
/*     */ 
/* 297 */     throw new FieldNumberOutOfBoundException(null, "TUPLE:TUPLE_FLDNO_OUT_OF_BOUND");
/*     */   }
/*     */ 
/*     */   public Tuple setFloFld(int paramInt, float paramFloat)
/*     */     throws IOException, FieldNumberOutOfBoundException
/*     */   {
/* 312 */     if ((paramInt > 0) && (paramInt <= this.fldCnt))
/*     */     {
/* 314 */       Convert.setFloValue(paramFloat, this.fldOffset[(paramInt - 1)], this.data);
/* 315 */       return this;
/*     */     }
/*     */ 
/* 318 */     throw new FieldNumberOutOfBoundException(null, "TUPLE:TUPLE_FLDNO_OUT_OF_BOUND");
/*     */   }
/*     */ 
/*     */   public Tuple setStrFld(int paramInt, String paramString)
/*     */     throws IOException, FieldNumberOutOfBoundException
/*     */   {
/* 334 */     if ((paramInt > 0) && (paramInt <= this.fldCnt))
/*     */     {
/* 336 */       Convert.setStrValue(paramString, this.fldOffset[(paramInt - 1)], this.data);
/* 337 */       return this;
/*     */     }
/*     */ 
/* 340 */     throw new FieldNumberOutOfBoundException(null, "TUPLE:TUPLE_FLDNO_OUT_OF_BOUND");
/*     */   }
/*     */ 
/*     */   public void setHdr(short paramShort, AttrType[] paramArrayOfAttrType, short[] paramArrayOfShort)
/*     */     throws IOException, InvalidTypeException, InvalidTupleSizeException
/*     */   {
/* 360 */     if ((paramShort + 2) * 2 > 1024) {
/* 361 */       throw new InvalidTupleSizeException(null, "TUPLE: TUPLE_TOOBIG_ERROR");
/*     */     }
/* 363 */     this.fldCnt = paramShort;
/* 364 */     Convert.setShortValue(paramShort, this.tuple_offset, this.data);
/* 365 */     this.fldOffset = new short[paramShort + 1];
/* 366 */     int i = this.tuple_offset + 2;
/*     */ 
/* 370 */     this.fldOffset[0] = ((short)((paramShort + 2) * 2 + this.tuple_offset));
/*     */ 
/* 372 */     Convert.setShortValue(this.fldOffset[0], i, this.data);
/* 373 */     i += 2;
/* 374 */     int j = 0;
/*     */     int k;
/* 378 */     for (short s = 1; s < paramShort; s++)
/*     */     {
/* 380 */       switch (paramArrayOfAttrType[(s - 1)].attrType)
/*     */       {
/*     */       case 1:
/* 383 */         k = 4;
/* 384 */         break;
/*     */       case 2:
/* 387 */         k = 4;
/* 388 */         break;
/*     */       case 0:
/* 391 */         k = (short)(paramArrayOfShort[j] + 2);
/* 392 */         j = (short)(j + 1);
/* 393 */         break;
/*     */       default:
/* 396 */         throw new InvalidTypeException(null, "TUPLE: TUPLE_TYPE_ERROR");
/*     */       }
/* 398 */       this.fldOffset[s] = ((short)(this.fldOffset[(s - 1)] + k));
/* 399 */       Convert.setShortValue(this.fldOffset[s], i, this.data);
/* 400 */       i += 2;
/*     */     }
/*     */ 
/* 403 */     switch (paramArrayOfAttrType[(paramShort - 1)].attrType)
/*     */     {
/*     */     case 1:
/* 406 */       k = 4;
/* 407 */       break;
/*     */     case 2:
/* 410 */       k = 4;
/* 411 */       break;
/*     */     case 0:
/* 414 */       k = (short)(paramArrayOfShort[j] + 2);
/* 415 */       break;
/*     */     default:
/* 418 */       throw new InvalidTypeException(null, "TUPLE: TUPLE_TYPE_ERROR");
/*     */     }
/*     */ 
/* 421 */     this.fldOffset[paramShort] = ((short)(this.fldOffset[(s - 1)] + k));
/* 422 */     Convert.setShortValue(this.fldOffset[paramShort], i, this.data);
/*     */ 
/* 424 */     this.tuple_length = (this.fldOffset[paramShort] - this.tuple_offset);
/*     */ 
/* 426 */     if (this.tuple_length > 1024)
/* 427 */       throw new InvalidTupleSizeException(null, "TUPLE: TUPLE_TOOBIG_ERROR");
/*     */   }
/*     */ 
/*     */   public short noOfFlds()
/*     */   {
/* 440 */     return this.fldCnt;
/*     */   }
/*     */ 
/*     */   public short[] copyFldOffset()
/*     */   {
/* 452 */     short[] arrayOfShort = new short[this.fldCnt + 1];
/* 453 */     for (int i = 0; i <= this.fldCnt; i++) {
/* 454 */       arrayOfShort[i] = this.fldOffset[i];
/*     */     }
/*     */ 
/* 457 */     return arrayOfShort;
/*     */   }
/*     */ 
/*     */   public void print(AttrType[] paramArrayOfAttrType)
/*     */     throws IOException
/*     */   {
/* 472 */     System.out.print("[");
/*     */     int j;
/*     */     float f;
/*     */     String str;
/* 473 */     for (int i = 0; i < this.fldCnt - 1; i++)
/*     */     {
/* 475 */       switch (paramArrayOfAttrType[i].attrType)
/*     */       {
/*     */       case 1:
/* 478 */         j = Convert.getIntValue(this.fldOffset[i], this.data);
/* 479 */         System.out.print(j);
/* 480 */         break;
/*     */       case 2:
/* 483 */         f = Convert.getFloValue(this.fldOffset[i], this.data);
/* 484 */         System.out.print(f);
/* 485 */         break;
/*     */       case 0:
/* 488 */         str = Convert.getStrValue(this.fldOffset[i], this.data, this.fldOffset[(i + 1)] - this.fldOffset[i]);
/* 489 */         System.out.print(str);
/* 490 */         break;
/*     */       case 3:
/*     */       case 4:
/*     */       }
/*     */ 
/* 496 */       System.out.print(", ");
/*     */     }
/*     */ 
/* 499 */     switch (paramArrayOfAttrType[(this.fldCnt - 1)].attrType)
/*     */     {
/*     */     case 1:
/* 502 */       j = Convert.getIntValue(this.fldOffset[i], this.data);
/* 503 */       System.out.print(j);
/* 504 */       break;
/*     */     case 2:
/* 507 */       f = Convert.getFloValue(this.fldOffset[i], this.data);
/* 508 */       System.out.print(f);
/* 509 */       break;
/*     */     case 0:
/* 512 */       str = Convert.getStrValue(this.fldOffset[i], this.data, this.fldOffset[(i + 1)] - this.fldOffset[i]);
/* 513 */       System.out.print(str);
/* 514 */       break;
/*     */     case 3:
/*     */     case 4:
/*     */     }
/*     */ 
/* 520 */     System.out.println("]");
/*     */   }
/*     */ 
/*     */   private short pad(short paramShort, AttrType paramAttrType)
/*     */   {
/* 535 */     return 0;
/*     */   }
/*     */ }

/* Location:           C:\Users\Ahmed\Documents\GitHub\HeapFile\javamini_hwk\assign\HeapFile\src\
 * Qualified Name:     heap.Tuple
 * JD-Core Version:    0.6.2
 */