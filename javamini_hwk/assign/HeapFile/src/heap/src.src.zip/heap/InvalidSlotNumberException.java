/*    */ package heap;
/*    */ 
/*    */ import chainexception.ChainException;
/*    */ 
/*    */ public class InvalidSlotNumberException extends ChainException
/*    */ {
/*    */   public InvalidSlotNumberException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public InvalidSlotNumberException(Exception paramException, String paramString)
/*    */   {
/* 15 */     super(paramException, paramString);
/*    */   }
/*    */ }

/* Location:           C:\Users\Ahmed\Documents\GitHub\HeapFile\javamini_hwk\assign\HeapFile\src\
 * Qualified Name:     heap.InvalidSlotNumberException
 * JD-Core Version:    0.6.2
 */