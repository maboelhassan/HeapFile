/*    */ package heap;
/*    */ 
/*    */ import chainexception.ChainException;
/*    */ 
/*    */ public class InvalidTupleSizeException extends ChainException
/*    */ {
/*    */   public InvalidTupleSizeException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public InvalidTupleSizeException(Exception paramException, String paramString)
/*    */   {
/* 13 */     super(paramException, paramString);
/*    */   }
/*    */ }

/* Location:           C:\Users\Ahmed\Documents\GitHub\HeapFile\javamini_hwk\assign\HeapFile\src\
 * Qualified Name:     heap.InvalidTupleSizeException
 * JD-Core Version:    0.6.2
 */